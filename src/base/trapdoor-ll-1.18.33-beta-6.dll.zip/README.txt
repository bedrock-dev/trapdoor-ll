**配置文件暂时放到BDS根目录**

**需要LiteLoader作为前置依赖**

